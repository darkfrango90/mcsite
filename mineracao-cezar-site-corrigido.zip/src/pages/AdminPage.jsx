import React from 'react';
import Admin from '../components/Admin/Admin';

function AdminPage() {
  return (
    <div className="admin-page">
      <Admin />
    </div>
  );
}

export default AdminPage;

